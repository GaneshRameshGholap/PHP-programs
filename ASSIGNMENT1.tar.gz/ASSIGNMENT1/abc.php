<html>
<head>
<title>My first php program</title>
</head>
<body>
<?php
echo "hello world";
?>
</body>
</html>
