<?php
$a=$_GET['txtn1'];
$b=$_GET['txtn2'];
$sum=$a+$b;
echo "addition is:$sum";
?>
