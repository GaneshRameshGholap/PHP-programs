<?php
  	$no1=$_GET['txtno1'];
	$no2=$_GET['txtno2'];
         
?>
