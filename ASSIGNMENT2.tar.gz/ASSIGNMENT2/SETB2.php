<?php
$a=array("a"=>"red","b"=>"green","c"=>"blue");
echo array_search("red",$a);
echo in_array("red",$a);
?> 
