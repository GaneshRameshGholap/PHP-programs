<?php
$multi = array(array(1,2),array(3,4),array(5,6));
//print_r
//$multi = array(1,2,3);
echo "$multi[1][0]";
?>
