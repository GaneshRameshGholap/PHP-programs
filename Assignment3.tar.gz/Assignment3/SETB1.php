<?php
    class Rectangle
    {

    }
