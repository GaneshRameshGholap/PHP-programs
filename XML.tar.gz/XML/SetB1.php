<?php
	header('Content-type:text/xml');
	echo "<?xml version='1.0' encoding='ISO-8859-1'?>
	<CD_Store>
		<Movie>
			<Title>Mr.India</Title>
			<Release_Year>1987</Release_Year>
		</Movie>
                <Movie>
                        <Title>Holiday</Title>
                        <Release_Year>2014</Release_Year>
                </Movie>
                <Movie>
                        <Title>LOC</Title>
                        <Release_Year>2003</Release_Year>
                </Movie>
        </CD_Store>";
?>
