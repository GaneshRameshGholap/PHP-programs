<?php
session_start();
echo $_SESSION['sname'];
echo $_SESSION['sclass'];
?>
