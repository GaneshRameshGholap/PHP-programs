<?php
	echo "<html><head></head>";
        echo "<body bgcolor=$_COOKIE[bgcolor]>";
        echo "<font face=$_COOKIE[fstyle] color=$_COOKIE[fcolor] size= $_COOKIE[fsize]>$_COOKIE[text]</font>";
        echo "</body></html>";
?>
