import java.io.*;

class Byte_file_read
{

	public static void main(String arg[]) throws IOException
	{
		File f=new File("Byte_file_read.java");
		FileInputStream fis=new FileInputStream(f);
	//	BufferedReader br=new BufferedReader(new InputStreamReader(fis));
		int n;
		//String n;
		if(f.exists())
		{
			while((n=fis.read())!=-1)

				System.out.print((char)n);



			/*	while((n=br.readLine())!=null)

				System.out.print(n);
*/
		}
		else
		{
			System.out.print("File does not exist");
		}
		fis.close();

	}


}