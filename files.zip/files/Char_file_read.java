import java.io.*;

class Char_file_read
{

	public static void main(String arg[])	throws IOException
	{
		File f=new File("Byte_file_read.java");
		FileReader fis=new FileReader(f);
	BufferedReader br=new BufferedReader(fis);

		String n;
		if(f.exists())
		{
			while((n=br.readLine())!=null)

				System.out.print(n);

		}
		else
		{
System.out.print("File does not exist");
		}
		fis.close();

	}
}