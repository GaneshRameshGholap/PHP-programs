import java.io.*;

class Char_file_read_WOBFFR
{

	public static void main(String arg[]) throws IOException
	{
		File f=new File("F:/ashish dhoke/Ashish_Notes/java/SEM 1/simple programs/prime1.java");
		FileReader fis=new FileReader(f);
		BufferedReader br=new BufferedReader(fis);



		int n;
		if(f.exists())
		{
			while((n=fis.read())!=-1)

				System.out.print((char)n);

		}
		else
		{
			System.out.print("File does not exist");
		}
		fis.close();

	}


}