import java.io.*;
import java.util.*;

public class DeleteFileWithExtension
{

		public static void main(String[] args)
		{
			File file = new File(".");
			File str[]=file.listFiles();
			int doccount=0;

			for(int i=0;i<str.length;i++)
			{
				String s=str[i].getName();
				if(s.endsWith(".txt"))
				{
					doccount++;
					System.out.println("File "+str[i]+" deleted.");
					str[i].delete();
				}
			}
System.out.println("Total txt file in current diretory are :"+doccount);
		}
}