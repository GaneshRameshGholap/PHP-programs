import java.io.*;

class PrimitiveTypes
{
public static void main(String args[]) throws IOException
{

FileOutputStream fos=new FileOutputStream("info.doc");
DataOutputStream dos=new DataOutputStream(fos);
dos.writeInt(25);
dos.writeBoolean(true);
dos.writeChar('A');
dos.writeDouble(5.45);
dos.write("ashish");
dos.close();


FileInputStream fis=new FileInputStream("info.doc") ;
DataInputStream dis=new DataInputStream(fis);
int num =dis.readInt();
boolean b=dis.readBoolean();
char ch=dis.readChar();
double dbl= dis.readDouble();


System.out.println("Int- "+num +"\nBoolean- "+b);
System.out.println("\nCharacter- "+ch+"\nDouble- "+dbl);
fis.close();
}
}