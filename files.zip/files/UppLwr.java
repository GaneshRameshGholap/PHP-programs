import java.io.*;
class UppLwr
{
        public static void main(String args[])
        {
String strdest="D:/ashish dhoke/Ashish_Notes/java/SEM 1/simple programs/files/temp.docx";
                File f1=new File("temp.docx");
                try{
  		FileReader fis=new FileReader(strdest);
		BufferedReader br=new BufferedReader(fis);
                if(f1.isFile())
                {
				System.out.println("File exists");
					   		String n;
	   			while((n=br.readLine())!=null)
		   			System.out.print(n);
				}
                else
                {
					try{
						System.out.println("File does not exists");
                       FileWriter fw=new FileWriter(strdest);
 BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
                        int ch;
                        while((ch=br1.read())!='*')
                        {
                                if(Character.isLowerCase(ch))
                                {
                                      ch=Character.toUpperCase(ch);
                                        fw.write(ch);
                                }
                                else if(Character.isUpperCase(ch))
                                {
                                     ch=Character.toLowerCase(ch);
                                        fw.write(ch);
                                }
                                else if(Character.isDigit(ch))
                                {
                                        ch='*';
                                        fw.write(ch);
                                }
                                else
                                        fw.write((char)ch);
                        }
                        fw.close();
                        }
                        catch(Exception e)
{System.out.println(e);}
                }
                }catch(Exception e)
{System.out.println(e);}


        }
}
