import java.io.*;
class countcharline
{
        public static void main(String args[])
        {

 String strdest="countcharline.java";
                File f1=new File(strdest);
                try{
               		FileReader fis=new FileReader(f1);
		BufferedReader br=new BufferedReader(fis);
                if(f1.isFile())
                {
				System.out.println("File exists");
				int n,charcount=0,linecount=0,wordcount=0;

	   	while((n=fis.read())!=-1)
	   	{
		if(Character.isLetter((char)n))
		{
				charcount++;
		}
			if((char)n==' '||(char)n=='\n')
				{
					wordcount++;
				}
				if((char)n=='\n')
				{
					linecount++;
						}
				}
System.out.println("Total Word count : "
+wordcount+"\nTotal Line count : "+
linecount+"\nTotal Charcter count : "+charcount);

				}
                else
                {
						System.out.println("File does not exists");
                }
                }
                catch(Exception e)
			{
		System.out.println(e);
				}


        }
}
