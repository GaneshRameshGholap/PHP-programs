import java.io.*;
public class filecopy
{
        public static void main(String[] args)
        {
  String strSourceFile="D:/ASHISH NOTES/JAVA/SEM 1/simple programs/files/filecopy.java";
  String strDestinationFile="copied1234.doc";
                try
                {

    FileInputStream fin = new FileInputStream(strSourceFile);

	FileOutputStream fout = new FileOutputStream(strDestinationFile);
   // byte[] b = new byte[1250];
  	System.out.println("Copying file using streams");
	int i=0;
    while((i=fin.read()) != -1)
    {
		fout.write(i);
	}
/*
while((fin.read(b)) != -1);


  fout.write(b);
*/
    System.out.println("File copied!");
     fin.close();
      fout.close();
      }
      catch(FileNotFoundException fnf)
      {
           System.out.println("Specified file not found :" + fnf);
      }
      catch(IOException ioe)
       {
            System.out.println("Error while copying file :" + ioe);
        }
 	}
}
