import java.io.*;

public class filecopy1
{

        public static void main(String[] args)
        {

  String strSourceFile="D:/ASHISH NOTES/JAVA/SEM 1/simple programs/files/filecopy1.java";
  String strDestinationFile="copied111.doc";
                try
                {
    FileReader fin = new FileReader(strSourceFile);
    FileWriter fout = new FileWriter(strDestinationFile);


        int ch = 0;
        System.out.println("Copying file using FileReader & FileWriter");
        while( (ch = fin.read()) != -1 )
        {
            fout.write(ch);
        }

        System.out.println("File copied!");

        fin.close();
        fout.close();
       }
        catch(FileNotFoundException fnf)
         {
         System.out.println("Specified file not found :" + fnf);
        }
       catch(IOException ioe)
      {
          System.out.println("Error while copying file :" + ioe);
     }
 }
}
