

import java.io.*;
class seta2
{
        public static void main(String args[])throws IOException
        {
                File f1=new File(args[0]);
                if(!f1.isFile())
                        System.out.println("File does not exists");
                else
                {
                        FileWriter fw=new FileWriter(args[1]);
                        FileReader fr=new FileReader(args[0]);
                        int ch;
                        while((ch=fr.read())!=-1)
                        {
                                if(Character.isLowerCase(ch))
                                {
                                        ch=Character.toUpperCase(ch);
                                        fw.write(ch);
                                }
                                else if(Character.isUpperCase(ch))
                                {
                                        ch=Character.toLowerCase(ch);
                                        fw.write(ch);
                                }
                                else if(Character.isDigit(ch))
                                {
                                        ch='*';
                                        fw.write(ch);
                                }
                                else
                                        fw.write((char)ch);
                        }
                        fr.close();
                        fw.close();
                }
        }
}
