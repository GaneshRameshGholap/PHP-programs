

import java.io.*;

class seta3
{
        public static void main(String args[])throws IOException
        {		File f=new File("a.txt");
                FileInputStream fis=new FileInputStream(f);
                BufferedInputStream bis=new BufferedInputStream(fis);
                System.out.println("The contents in reverse order are:");
                long size=f.length();
                for(long i=size-1;i>=0;i--)
                {

                      bis.mark(0);
                        bis.skip(i);
                        System.out.print((char)bis.read());
                       bis.reset();
                }
                bis.close();
        }
}
