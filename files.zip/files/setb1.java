

import java.io.*;
class setb1
{
        public static void main(String args[])throws IOException
        {
                FileWriter fw=new FileWriter("item.dat");
                String ch="";
                String name;
                int id,price,qty,ch1;
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                System.out.println("Do you want to enter the details of product?");
                        ch=br.readLine();
                while(!ch.equals("n"))
                {
                     System.out.println("Enter the item information of(id,name,price,quantity):");
                         id=Integer.parseInt(br.readLine());
                        fw.write(new Integer(id).toString()+"\n");
                         name=br.readLine();
                        fw.write(name+"\n");
                         price=Integer.parseInt(br.readLine());
                        fw.write(new Integer(price).toString()+"\n");
                         qty=Integer.parseInt(br.readLine());
                        fw.write(new Integer(qty).toString()+"\n");
                        System.out.println("Do you want to continue?");
                        ch=br.readLine();
                }
                fw.close();

                do
                {
                      System.out.println("1-Search by item name\n2-Find costliest item\n3-Display all and total cost\n4-Exit");
                        System.out.println("Enter your choice:");
                        ch1=Integer.parseInt(br.readLine());
                        BufferedReader br1=new BufferedReader(new FileReader("item.dat"));
                        br1.mark(100);
                        switch(ch1)
                        {
                                case 1: System.out.println("Enter the item name to be searched:");
                                        String s,name1;
                                        name1=br.readLine();
                                        while((s=br1.readLine())!=null)
                                        {
                                                id=Integer.parseInt(s);
                                                name=br1.readLine();
                                                price=Integer.parseInt(br1.readLine());
                                                qty=Integer.parseInt(br1.readLine());
                                                if(name.equals(name1))
                                                {
                                                        System.out.println("Id- "+id+"\nName- "+name+"\nPrice- "+price);
                                                        System.out.println("Quantity- "+qty);
                                                }
                                        }
                                        br1.reset();
                                        break;
                                case 2: String s1;
                                        int max=0;
                                        while((s1=br1.readLine())!=null)
                                        {
                                                id=Integer.parseInt(s1);
                                                name=br1.readLine();
                                                price=Integer.parseInt(br1.readLine());
                                                qty=Integer.parseInt(br1.readLine());
                                                if(price>max)
                                                        max=price;
                                        }
                                        br1.reset();
                                        while((s1=br1.readLine())!=null)
                                        {
                                                id=Integer.parseInt(s1);
                                                name=br1.readLine();
                                                price=Integer.parseInt(br1.readLine());
                                                qty=Integer.parseInt(br1.readLine());
                                                if(price==max)
                                                {       System.out.println("Id- "+id+"\nName- "+name+"\nPrice- "+price);
                                                        System.out.println("Quantity- "+qty);
                                                }

                                        }
                                        br1.reset();
                                        break;
                                case 3: int total=0;
                                        String s2;
                                        while((s2=br1.readLine())!=null)
                                        {
                                                id=Integer.parseInt(s2);
                                                name=br1.readLine();
                                                price=Integer.parseInt(br1.readLine());
                                                qty=Integer.parseInt(br1.readLine());
                                                System.out.println("Id- "+id+"\nName- "+name+"\nPrice- "+price);
                                                System.out.println("Quantity- "+qty);
                                                total+=price;
                                                System.out.println("The total cost: "+total);
                                        }
                                        br1.reset();
                                        break;

                        }
                }while(ch1!=4);

        }
}

