/*NAME:Alpesh Rathod
 ROLL.NO:213*/

/*SET B2 Write a program to store student information(rno,name,per)in a RandomAccessFile  "student.dat".Display the details of the student having a specific roll number*/

import java.io.*;
class setb2
{
        public static void main(String args[])throws IOException
        {
                RandomAccessFile f=new RandomAccessFile("student.dat","rw");
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                int n,rno,perc,i;
                String name;
                String ch="";
                System.out.println("Enter how many records you want to?");
                n=Integer.parseInt(br.readLine());
                for(i=0;i<n;i++)
                {
                        System.out.println("Enter the details of the" +(i+1)+" student");
                        rno=Integer.parseInt(br.readLine());
                        name=br.readLine();
                        perc=Integer.parseInt(br.readLine());
                        f.writeInt(rno);
                        f.writeUTF(name);
                        f.writeInt(perc);
                }
                //f.seek(0);
                while(!ch.equals("n"))
                {
                        f.seek(0);
                        System.out.println("Enter the student roll number to be searched:");
                        int no1;
                        no1=Integer.parseInt(br.readLine());
                        for(i=0;i<n;i++)
                        {
                        rno=f.readInt();
                        name=f.readUTF();
                        perc=f.readInt();
                        if(rno==no1)
                              System.out.println("Rno- "+rno +"\nName- "+ name +"\nPerc- "+perc);
                        }
                        System.out.println("Do you want to continue ? Y/N");
                        ch=br.readLine();
                }
                f.close();
        }
}
