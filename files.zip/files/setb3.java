

import java.io.*;
class setb3
{
        public static void main(String args[])throws IOException
        {
                if(args.length!=3)
                {
                        FileReader fr=new FileReader(args[0]);
                        BufferedReader br=new BufferedReader(fr);
                        String s;
                        String str=args[1];
                        while((s=br.readLine())!=null)
                        {
                                if(s.indexOf(str)!=-1)
                                        System.out.println(s);
                        }
                }
                else
                {
                        int count=0,count1=0;
                        FileReader fr=new FileReader(args[1]);
                        BufferedReader br=new BufferedReader(fr);
                        String option=args[0];
                        String s;
                        String str=args[2];
                        if(option.equals("-c"))
                        {
                                while((s=br.readLine())!=null)
                                {
                                        if(s.indexOf(str)!=-1)
                                                count++;
                                }
                             System.out.println("No of lines containing the string are: "+count);
                        }
                        else if(option.equals("-v"))
                        {
                                while((s=br.readLine())!=null)
                                {
                                        if(s.indexOf(str)==-1)
                                                count1++;
                                }
                         System.out.println("No of lines not containing the string are: "+count1);
                        }

                }
        }
}
