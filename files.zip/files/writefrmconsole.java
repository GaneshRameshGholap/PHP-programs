import java.io.*;

public class writefrmconsole
{

        public static void main(String[] args)
        {
               try
                {

    FileWriter fout = new FileWriter("copied2.doc");
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

       String str;

        while((!(str = br.readLine()).equals("end")) )
        {
            fout.write(str+"\n");
        }

        System.out.println("Content wirtten in the file!!!!!");

        br.close();
        fout.close();
       }
        catch(FileNotFoundException fnf)
         {
         System.out.println("Specified file not found :" + fnf);
        }
       catch(IOException ioe)
      {
          System.out.println("Error while copying file :" + ioe);
     }
 }
}
