<!doctype html>
<html>
<body>
<script>
Document.write("Hello World");
</script>
</body>
</html>

